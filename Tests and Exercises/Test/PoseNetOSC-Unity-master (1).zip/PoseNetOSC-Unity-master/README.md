# PoseNetOSC-Unity

This project is based on these other projects: 

PoseNet to OSC adaptation
https://github.com/tommymitch/posenetosc 

extOSC unity package
https://assetstore.unity.com/packages/tools/input-management/extosc-open-sound-control-72005

Follow the instructions to run PoseNet OSC and then run the Unity project
